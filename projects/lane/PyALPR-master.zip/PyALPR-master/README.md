PyALPR
======

For more details please visit http://lukagabric.com/raspberry-pi-license-plate-recognition/
